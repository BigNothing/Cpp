﻿using System;
using System.IO;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

/*

16. Програма за родословно дърво. Интерфейс за въвеждане на данни за членовете на един род. 
(Име, дата на раждане,  родом от и други)
Да се ползва контрола тип дърво. Данните да се съхраняват като XML или текстов файл.

*/


namespace FamilyTree{


    public partial class MainWindow : Window {
        
        List<Person> root = new List<Person>();

        

        Person family1 = new Person("male") { Name = "The Doe's" };
        Person family2 = new Person("male") { Name = "The Moe's"};
        Person family3 = new Person("female") { Name = "jikita" };

        public MainWindow(){

            InitializeComponent();

            
            family1.Members.Add(new Person("male") { Name = "John Doe" });
            family1.Members.Add(new Person("female") { Name = "Jane Doe" });
            family1.Members.Add(new Person("female") { Name = "Sammy Doe" });

            family1.Members.Single(FamilyMember => FamilyMember.Name == "Sammy Doe").Members.Add(new Person("female") { Name = "asdsdaoisjdo" });

            //list.Where(x => x.Title == title)

            root.Add(family1);

            


            family2.Members.Add(new Person("male") { Name = "Mark Moe", Gender = "male" });
            family2.Members.Add(new Person("female") { Name = "Norma Moe", Gender = "female" });
            root.Add(family2);

            root.Add(family3);

            trvFamilies.ItemsSource = root;
            

        }

        private void btnCreate_Click(object sender, RoutedEventArgs e) {

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Are you sure?", "Delete Confirmation", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes) { 
                
                root = new List<Person>();
                trvFamilies.ItemsSource = root;
                
            }


            //TODO
        }



        private void btnAddNewPerson_Click(object sender, RoutedEventArgs e) {

           
            Person selectedRoot = (Person)trvFamilies.SelectedItem;

            Person newFamily = new Person("female") {
                Name = txtName.Text,
                Birthday = txtBirthday.Text,
                Birthplace = txtBirthplace.Text

            };

            selectedRoot.Members.Add(newFamily);
            

            /*
            addFamily(newFamily, root);*/


            
        }


        public void addFamily(Person newFamily, List<Person> group) {

            if (group.Count > 0) { 

                foreach (Person family in group) {

                    if (family.Name == txtParent.Text) {

                        //Add new Person if this is his parent

                        family.Members.Add(newFamily);

                        return;
                        
                    } else if (family.Members.Count > 0) {

                        addFamily(newFamily, family.Members.ToList());

                    }

                }

            } else {

                root = new List<Person>();
                root.Add(newFamily);
                trvFamilies.ItemsSource = root;

            }
        }


        private void btnRead_Click(object sender, RoutedEventArgs e) {

            ReadXML();

        }

        private void btnSaveData_Click(object sender, RoutedEventArgs e) {


            WriteXML();


        }

        

        public void WriteXML() {

            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.FileName = "XML_Data"; // Default file name
            dlg.DefaultExt = ".xml"; // Default file extension
            //dlg.Filter = "XML documents (.xml)|*.txt"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = dlg.ShowDialog();
            
            // Process save file dialog box results
            if (result == true) {
                // Save document
                string filename = dlg.FileName;


                System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(typeof(List<Person>));

                //var path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "//SerializationOverview.xml";

                System.IO.FileStream file = System.IO.File.Create(filename);

                writer.Serialize(file, root);
                file.Close();
                
            }
            
            
        }


        public void ReadXML() {

            string filePath;
            // Create OpenFileDialog 
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            // Set filter for file extension and default file extension 
            dlg.DefaultExt = ".xml";

            //dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";

            // Display OpenFileDialog by calling ShowDialog method 
            Nullable<bool> result = dlg.ShowDialog();

            // Get the selected file name and display in a TextBox 
            if (result == true) {
                // Open document 
                filePath = dlg.FileName;
                // Now we can read the serialized book ...
                System.Xml.Serialization.XmlSerializer reader = new System.Xml.Serialization.XmlSerializer(typeof(List<Person>));

                //var path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "//" + filePath;

                System.IO.StreamReader file = new System.IO.StreamReader(filePath);
                List<Person> overview = (List<Person>)reader.Deserialize(file);
                file.Close();

                trvFamilies.ItemsSource = overview;

                root = overview;
            }
            
        }

        private void trvFamilies_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {



            //Perform actions when SelectedItem changes
           // MessageBox.Show(((TreeViewItem)e.NewValue).






            

        }
    }

    public class Person {

        public string Name { get; set; }
        public string Birthday { get; set; }
        public string Birthplace { get; set; }
        public string imgSrc { get; set; }
        public string Gender { get; set; }
        public ObservableCollection<Person> Members { get; set; }
        
        
        public Person(String gen) {
            

            this.Members = new ObservableCollection<Person>();

            if (gen.Equals("female")) { 

                this.imgSrc = "C:\\Users\\Spark\\Documents\\Visual Studio 2015\\Projects\\FamilyTree\\FamilyTree\\female_icon.png";

            } else {

                this.imgSrc = "C:\\Users\\Spark\\Documents\\Visual Studio 2015\\Projects\\FamilyTree\\FamilyTree\\male_icon.png";
            }

        }
        
    }



  /*  public class FamilyMember {
        
        public String Name { get; set; }
        public int Age { get; set; }

    }*/


}
  